# Estrellas Bridge: votación del público

El público vota desde el celular el tipo de estrella (Gigante azul, Gigante roja, Nebulosa, Supernova).
El bridge cuenta los votos (uno por celular y por ronda) y le manda a TouchDesigner el color ganador por OSC/UDP.

```
Celulares --(socket.io)--> server.js (puerto 3000) --(OSC/UDP)--> TouchDesigner (puerto 7001)
```

## Ponerlo a andar

1. Abre esta carpeta en Visual Studio Code y en la Terminal ejecuta `npm install` (solo la primera vez).
2. Ejecuta `npm start`.
3. En la pestaña **PORTS**, haz **Forward a Port** del 3000 y pon la visibilidad en **Public**.
4. Abre en tu computador `http://localhost:3000/desktop/` (tu panel).
5. El QR del público apunta a `https://<URL de PORTS>/mobile/`.

## Mensajes OSC que llegan a TouchDesigner (puerto 7001)

| Dirección | Valores | Uso |
|---|---|---|
| `/publico/color` | r g b (0 a 1) | Color ganador, para `color_publico` |
| `/publico/ganador` | 0 a 3 | Número de la opción ganadora |
| `/publico/porcentaje` | 4 valores (0 a 100) | Barras en vivo en la proyección |
| `/publico/restante` | segundos | Cuenta regresiva de la ronda |

## Ajustes (arriba en server.js)

`RONDA_SEG` (duración de la ronda), `TD_PORT`, `OPCIONES` (nombres y colores) e `INICIAL` (color de arranque).
