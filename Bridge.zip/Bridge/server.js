// =====================================================================
//  Estrellas Bridge
//  Celulares del público  --(socket.io)-->  este servidor  --(OSC/UDP)-->  TouchDesigner
//
//  /mobile/   página de votación para el público (la del QR)
//  /desktop/  panel tuyo: resultados en vivo y control de rondas
// =====================================================================

const express = require('express')
const http = require('http')
const socketIO = require('socket.io')
const dgram = require('dgram')

// ---------- Ajustes ----------
const PORT      = 3000           // puerto web (el que reenvías en VS Code)
const TD_HOST   = '127.0.0.1'    // TouchDesigner en este mismo computador
const TD_PORT   = 7001           // OSC In CHOP "osc_publico" en TouchDesigner
const RONDA_SEG = 45             // duración de cada ronda

// Las 4 opciones, en orden 0..3. r, g, b de 0 a 1 (listos para TouchDesigner).
// "hex" es solo el color del botón en el celular.
const OPCIONES = [
  { nombre: 'Gigante azul', detalle: 'La más caliente',        hex: '#4D8CFF', r: 0.30, g: 0.55, b: 1.00 },
  { nombre: 'Gigante roja', detalle: 'Una estrella que muere', hex: '#FF4A2E', r: 1.00, g: 0.29, b: 0.18 },
  { nombre: 'Nebulosa',     detalle: 'Donde nacen',            hex: '#D940C4', r: 0.85, g: 0.25, b: 0.77 },
  { nombre: 'Supernova',    detalle: 'La explosión final',     hex: '#FFD966', r: 1.00, g: 0.85, b: 0.40 },
]
const INICIAL = 0                // opción con la que arranca la estrella

// ---------- OSC por UDP (sin librerías extra) ----------
const udp = dgram.createSocket('udp4')

function oscString(s) {
  const b = Buffer.from(s + '\0', 'utf8')
  const pad = (4 - (b.length % 4)) % 4
  return Buffer.concat([b, Buffer.alloc(pad)])
}

// args: números -> float32 ('f'), enteros marcados {i: n} -> int32 ('i')
function enviarOSC(address, ...args) {
  let tags = ','
  const datos = []
  for (const a of args) {
    if (a && typeof a === 'object' && 'i' in a) {
      tags += 'i'; const b = Buffer.alloc(4); b.writeInt32BE(a.i); datos.push(b)
    } else {
      tags += 'f'; const b = Buffer.alloc(4); b.writeFloatBE(a); datos.push(b)
    }
  }
  const msg = Buffer.concat([oscString(address), oscString(tags), ...datos])
  udp.send(msg, TD_PORT, TD_HOST, err => { if (err) console.error('[osc] error:', err.message) })
}

// ---------- Estado de la votación ----------
let votos      = [0, 0, 0, 0]
let yaVotaron  = new Set()       // ids de celular que ya votaron en esta ronda
let restante   = RONDA_SEG
let activa     = true
let ganadorActual = INICIAL
let ronda      = 1

const total = () => votos.reduce((a, b) => a + b, 0)
const porcentajes = () => votos.map(v => total() ? Math.round(v * 100 / total()) : 0)

function estadoPublico() {
  return {
    opciones: OPCIONES.map(({ nombre, detalle, hex }) => ({ nombre, detalle, hex })),
    porcentajes: porcentajes(),
    votos, total: total(), restante, activa, ronda,
    ganador: ganadorActual,
    conectados: io.of('/').sockets.size,
  }
}

function aplicarOpcion(n) {
  ganadorActual = n
  const o = OPCIONES[n]
  enviarOSC('/publico/color', o.r, o.g, o.b)
  enviarOSC('/publico/ganador', { i: n })
}

function enviarConteoTD() {
  enviarOSC('/publico/porcentaje', ...porcentajes())
  enviarOSC('/publico/restante', restante)
}

function difundir() {
  io.emit('estado', estadoPublico())
}

function cerrarRonda() {
  const max = Math.max(...votos)
  let mensaje = 'Nueva ronda: toca una opción para votar'
  if (max > 0) {
    const empatadas = votos.map((v, n) => v === max ? n : -1).filter(n => n >= 0)
    const g = empatadas[Math.floor(Math.random() * empatadas.length)]
    aplicarOpcion(g)
    mensaje = `Ganó ${OPCIONES[g].nombre}. ¡Nueva ronda!`
    console.log(`[ronda ${ronda}] Ganó ${OPCIONES[g].nombre}  (${votos.join(' / ')})`)
  } else {
    console.log(`[ronda ${ronda}] Sin votos`)
  }
  votos = [0, 0, 0, 0]
  yaVotaron.clear()
  restante = RONDA_SEG
  ronda++
  enviarConteoTD()
  io.emit('ronda', { mensaje, ganador: ganadorActual })
  difundir()
}

setInterval(() => {
  if (!activa) return
  restante--
  if (restante <= 0) cerrarRonda()
  else { enviarOSC('/publico/restante', restante); difundir() }
}, 1000)

// ---------- Servidor web + socket.io ----------
const app = express()
const server = http.createServer(app)
const io = socketIO(server)

app.use(express.static('public'))
app.get('/', (req, res) => res.redirect('/mobile/'))

io.on('connection', socket => {
  socket.emit('estado', estadoPublico())
  difundir()   // actualiza el número de conectados

  // Voto de un celular. "id" lo guarda el celular, así recargar la página no da otro voto.
  socket.on('voto', ({ id, opcion } = {}) => {
    const n = Math.round(Number(opcion))
    const quien = String(id || socket.id)
    if (!(n >= 0 && n < OPCIONES.length)) return
    if (!activa) return socket.emit('aviso', 'La votación está en pausa')
    if (yaVotaron.has(quien)) return socket.emit('aviso', 'Ya votaste. Espera la próxima ronda')

    yaVotaron.add(quien)
    votos[n]++
    socket.emit('votado', { opcion: n, ronda })
    enviarConteoTD()
    difundir()
  })

  // Controles del panel /desktop/
  socket.on('control', ({ accion, valor } = {}) => {
    if (accion === 'cerrar') cerrarRonda()
    if (accion === 'pausa') { activa = !activa; if (activa) restante = RONDA_SEG; difundir() }
    if (accion === 'forzar') {
      const n = Math.round(Number(valor))
      if (n >= 0 && n < OPCIONES.length) { aplicarOpcion(n); difundir() }
    }
    console.log('[control]', accion, valor ?? '')
  })

  socket.on('disconnect', () => difundir())
})

server.listen(PORT, () => {
  aplicarOpcion(INICIAL)
  enviarConteoTD()
  console.log(`Bridge listo en http://localhost:${PORT}`)
  console.log(`  Público: http://localhost:${PORT}/mobile/`)
  console.log(`  Panel:   http://localhost:${PORT}/desktop/`)
  console.log(`  OSC a TouchDesigner: ${TD_HOST}:${TD_PORT}  ·  rondas de ${RONDA_SEG} s`)
})
