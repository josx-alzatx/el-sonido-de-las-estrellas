// Página del público: muestra las 4 opciones y manda el voto al bridge.

// Un id fijo por celular, para que recargar la página no dé un voto extra.
function idDelCelular() {
  let id = null
  try { id = localStorage.getItem('estrellas-id') } catch (e) {}
  if (!id) {
    id = Math.random().toString(36).slice(2) + Date.now().toString(36)
    try { localStorage.setItem('estrellas-id', id) } catch (e) {}
  }
  return id
}
const MI_ID = idDelCelular()

const socket = io()
const $ = s => document.querySelector(s)
let construido = false
let rondaVotada = null

function construir(opciones) {
  $('#botones').innerHTML = ''
  $('#resultados').innerHTML = ''
  opciones.forEach((o, n) => {
    const b = document.createElement('button')
    b.className = 'op' + (o.hex.toUpperCase() === '#FFD966' ? ' oscuro' : '')
    b.style.background = o.hex
    b.innerHTML = `<b>${o.nombre}</b><span>${o.detalle}</span>`
    b.onclick = () => {
      socket.emit('voto', { id: MI_ID, opcion: n })
      if (navigator.vibrate) navigator.vibrate(30)
    }
    $('#botones').appendChild(b)

    $('#resultados').insertAdjacentHTML('beforeend',
      `<span>${o.nombre}</span><div class="barra"><i style="background:${o.hex}"></i></div><span class="pct">0%</span>`)
  })
  construido = true
}

socket.on('connect', () => $('#conexion').classList.add('ok'))
socket.on('disconnect', () => {
  $('#conexion').classList.remove('ok')
  $('#tiempo').textContent = 'Reconectando…'
})

socket.on('estado', e => {
  if (!construido) construir(e.opciones)
  $('#tiempo').textContent = e.activa
    ? `Ronda ${e.ronda} · quedan ${e.restante} s · ${e.total} voto${e.total === 1 ? '' : 's'}`
    : 'Votación en pausa'
  const barras = document.querySelectorAll('.barra i')
  const pcts = document.querySelectorAll('.pct')
  e.porcentajes.forEach((p, n) => { barras[n].style.width = p + '%'; pcts[n].textContent = p + '%' })

  // Si empezó otra ronda, se puede volver a votar
  if (rondaVotada !== null && rondaVotada !== e.ronda) {
    rondaVotada = null
    document.body.classList.remove('votado')
    document.querySelectorAll('.op').forEach(b => b.classList.remove('elegido'))
  }
})

socket.on('votado', ({ opcion, ronda }) => {
  rondaVotada = ronda
  document.body.classList.add('votado')
  document.querySelectorAll('.op')[opcion].classList.add('elegido')
  $('#estado').textContent = 'Voto registrado. Mira la pantalla'
})

socket.on('aviso', texto => { $('#estado').textContent = texto })
socket.on('ronda', ({ mensaje }) => { $('#estado').textContent = mensaje })
